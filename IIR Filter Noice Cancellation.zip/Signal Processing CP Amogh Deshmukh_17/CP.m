% Course Project
% Amogh Deshmukh
% Roll No 17
% GR N0 12111267

%% 1.Load audio file
[y,Fs] = audioread("noisy01new.wav");
disp("Sampling Frequncy Fs = "+num2str(Fs)+"Hz");
% Compute the length of the audio signal
N = length(y);
Ts = 1/Fs;
disp("Length of audio signal N = "+num2str(N));
% Compute the time axis
t = (0:N-1)/Fs;
n = t/Ts;

%% 2.Plot the audio signal vs time
plot(t, y);
xlabel('Time (s)');
ylabel('Amplitude');
title('Audio Signal y(t)');

%% 3.Compute the Fourier Transform
Y = fft(y);
figure;

% Compute the magnitude of the FFT
Y_mag = abs(Y);

% Plot the magnitude of the FFT
f = (0:length(Y)-1)*Fs/length(Y); % Frequency vector
subplot(2,1,1),plot(f, Y_mag);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Magnitude of FFT of Noisy Audio Signal');

%% 5. Design appropriate filter

% Define the filter parameters.
fc = 700; % Cutoff frequency for the lowpass filters.
order = 20; % Filter order for the FIR filter.

% Design the FIR lowpass filter.
h = fir1(order, fc/(Fs/2), 'low', hann(order+1)); % FIR lowpass filter.

%% 6 
% freqz(b,a,[],Fs);
figure;

% Apply the FIR filter to the audio signal.
filteredSignal1 = filter(h, 1, y);

% Design the IIR lowpass filter using the butter function.
[b, a] = butter(9, fc/(Fs/2), 'low'); % IIR lowpass filter.

% Apply the IIR filter to the previously filtered signal.
filteredSignal2 = filter(b, a, filteredSignal1);

% Play the filtered audio signal.
playFSignal = audioplayer(filteredSignal2, Fs);
play(playFSignal);
%%  
p=fft(filteredSignal2);
mag=abs(p);
freq=n*Fs/N;
subplot(3,1,2);
stem(freq,mag);
xlabel("Frequency");
ylabel("Magnitude dft of an audio signal");
title("Magnitude of Filtered signal vs Frequency");
figure;

% Plot the time domain waveform of the filtered audio signal.
t = (0:length(y)-1)/Fs;
figure;
subplot(3,1,1);
plot(t, y);
xlabel('Time (s)');
ylabel('Amplitude');
title('Original Audio Signal (Time Domain)');
subplot(3,1,2);
plot(t, filteredSignal1);
xlabel('Time (s)');

ylabel('Amplitude');
title('Filtered Audio Signal (FIR Lowpass Filter, Time Domain)');
subplot(3,1,3);
plot(t, filteredSignal2);
xlabel('Time (s)');
ylabel('Amplitude');
title('Filtered Audio Signal (IIR Lowpass Filter, Time Domain)');